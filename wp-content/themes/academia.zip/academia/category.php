<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/8/2015
 * Time: 1:58 PM
 */
get_header();
g5plus_get_template( 'archive');
get_footer();