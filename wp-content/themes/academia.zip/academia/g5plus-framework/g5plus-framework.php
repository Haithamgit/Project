<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/1/2015
 * Time: 8:51 AM
 */

/*================================================
CORE FILES
================================================== */
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/global.class.php');
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/xmenu/xmenu.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/tax-meta-class/Tax-meta-class.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/meta-box/meta-box.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/install-demo/install-demo.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/resize.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/action.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/wp-core.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/filter.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/base.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/breadcrumb.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/head.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/header.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/footer.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/blog.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/woocommerce.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/widget-custom-class.php' );
require_once( G5PLUS_THEME_DIR . '/g5plus-framework/core/admin-profile.php' );
